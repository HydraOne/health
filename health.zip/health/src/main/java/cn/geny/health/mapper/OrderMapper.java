package cn.geny.health.mapper;

import cn.geny.health.po.Order;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * TODO
 *
 * @author wangjiahao
 * @date 2022/3/13 0:46
 */
public interface OrderMapper extends BaseMapper<Order> {
}