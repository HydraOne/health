package cn.geny.health.mapper;

import cn.geny.health.po.UserRole;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * TODO
 *
 * @author wangjiahao
 * @date 2022/3/13 0:46
 */
public interface UserRoleMapper extends BaseMapper<UserRole> {
}