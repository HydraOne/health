package cn.geny.health.mapper;

import cn.geny.health.po.User;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * TODO
 *
 * @author wangjiahao
 * @date 2022/3/6 0:10
 */
public interface UserMapper extends BaseMapper<User> {
}