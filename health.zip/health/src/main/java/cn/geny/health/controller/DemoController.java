package cn.geny.health.controller;

import cn.geny.health.utils.MinIoUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;

/**
 * TODO
 *
 * @author wangjiahao
 * @date 2022/3/22 10:28
 */
@RestController
@RequestMapping("/demo")
public class DemoController {
    @Autowired
    MinIoUtil minIoUtil;

    @PostMapping("/upload")
    public void uploadToMinio(String bucketName, MultipartFile file) {
        minIoUtil.upload(file,bucketName);
        System.out.println(1321);
    }

    @GetMapping("/download")
    public void downloadFromMinio(String bucketName, String filename, HttpServletResponse resp) {
        minIoUtil.download(bucketName,filename,resp);
    }
}
