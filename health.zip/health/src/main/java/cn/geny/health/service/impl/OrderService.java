package cn.geny.health.service.impl;

import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.List;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import cn.geny.health.po.Order;
import cn.geny.health.mapper.OrderMapper;
/** 
 * TODO
 * @author wangjiahao
 * @date 2022/3/13 0:46
 */
@Service
public class OrderService extends ServiceImpl<OrderMapper, Order> {

}
