package cn.geny.health.service.impl;

import cn.geny.health.common.RedisCache;
import cn.geny.health.constant.Constants;
import cn.geny.health.po.User;
import cn.geny.health.utils.CaptchaUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Component;

import java.util.concurrent.TimeUnit;

/**
 * TODO
 *
 * @author wangjiahao
 * @date 2022/3/7 9:26
 */
@Component
public class CaptchaService {
    @Autowired
    RedisCache redisCache;

    @Autowired
    JavaMailSender javaMailSender;

    @Autowired
    UserService userService;

    public String captchaCodeBindToken(String token) {
        String captchaCodeBindUUIDStr = Constants.CAPTCHA_CODE_KEY + token;
        String captchaCode = CaptchaUtil.generateCaptchaCode();
        redisCache.setCacheObject(captchaCodeBindUUIDStr, captchaCode, Constants.CAPTCHA_EXPIRATION, TimeUnit.MINUTES);
        return captchaCode;
    }

    public String captchaCodeSender(String token) {
        String userId = redisCache.getCacheObject(Constants.LOGIN_TOKEN_KEY + token);
        User user = userService.getById(userId);
        String captchaCode = captchaCodeBindToken(token);
        new Thread(() -> {
            SimpleMailMessage simpleMailMessage = new SimpleMailMessage();
            simpleMailMessage.setText(captchaCode);
            simpleMailMessage.setFrom("hydraone123@qq.com");
            simpleMailMessage.setTo(user.getContact());
            javaMailSender.send(simpleMailMessage);
        }).start();
        return captchaCode;
    }

    public boolean checkCaptchaCode(String token, String captchaCode) {
        String bindCaptchaCode = redisCache.getCacheObject(Constants.CAPTCHA_CODE_KEY + token);
        if (bindCaptchaCode.equals(captchaCode)) {
            return true;
        }
        return false;
    }
}