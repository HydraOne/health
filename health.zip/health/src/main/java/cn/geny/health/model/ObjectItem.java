package cn.geny.health.model;

import lombok.Data;

/**
 * TODO
 *
 * @author wangjiahao
 * @date 2022/3/22 10:25
 */
@Data
public class ObjectItem {
    private String objectName;
    private long size;
}
