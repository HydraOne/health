package cn.geny.health.service.impl;

import cn.geny.health.mapper.UserRoleMapper;
import cn.geny.health.po.UserRole;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;
/** 
 * TODO
 * @author wangjiahao
 * @date 2022/3/13 0:46
 */
@Service
public class UserRoleService extends ServiceImpl<UserRoleMapper, UserRole> {

}
