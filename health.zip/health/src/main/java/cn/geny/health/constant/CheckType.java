package cn.geny.health.constant;

/**
 * TODO
 *
 * @author wangjiahao
 * @date 2022/3/24 16:20
 */
public enum CheckType {
    Item,
    Group,
    Plan;
}
